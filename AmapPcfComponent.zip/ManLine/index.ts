import { IInputs, IOutputs } from "./generated/ManifestTypes";

import * as AMapLoader from "@amap/amap-jsapi-loader"


export class ManLine implements ComponentFramework.StandardControl<IInputs, IOutputs> {

    private _mapContainer: HTMLDivElement;

    private containerTemp: HTMLDivElement;

    private a: any;
    private dis: number;

    private key: string;
    private mar1: string;
    private mar2: string;
    private mar3: string;
    private mar4: string;

    /**
     * Empty constructor.
     */
    constructor() {
        this._mapContainer = document.createElement('div');
        this._mapContainer.setAttribute("id", "container")
        this._mapContainer.style.width = '390px';
        this._mapContainer.style.height = '512px';
    }


    public init(context: ComponentFramework.Context<IInputs>, notifyOutputChanged: () => void, state: ComponentFramework.Dictionary, container: HTMLDivElement): void {
        this.key = context.parameters.ApiKey.raw ?? '0823370bc52e0079dcdb5cec53b638b8';

        this.mar1 = context.parameters.Marker1long.raw ?? '0';

        this.mar2 = context.parameters.Marker1lat.raw ?? '0';

        this.mar3 = context.parameters.Marker2long.raw ?? '0';

        this.mar4 = context.parameters.Marker2lat.raw ?? '0';
        container.appendChild(this._mapContainer);
    }

    public updateView(context: ComponentFramework.Context<IInputs>): void {
        this.key = context.parameters.ApiKey.raw ? context.parameters.ApiKey.raw : '0823370bc52e0079dcdb5cec53b638b8';

        this.mar1 = context.parameters.Marker1long.raw ? context.parameters.Marker1long.raw : '0';

        this.mar2 = context.parameters.Marker1lat.raw ? context.parameters.Marker1lat.raw : '0';

        this.mar3 = context.parameters.Marker2long.raw ? context.parameters.Marker2long.raw : '0';

        this.mar4 = context.parameters.Marker2lat.raw ? context.parameters.Marker2lat.raw : '0';
        console.log("修改参数后地图变更")
        this.generateMap();
    }

    private generateMap() {
        AMapLoader.load({
            key: this.key,
            version: '1.4.15',
            plugins: ['AMap.Geocoder'],
        }).then((AMap: any) => {
            const map = new AMap.Map("container", {
                resizeEnable: true,
                zoom: 10
            });
            //计算两点间距离
            this.dis = Math.round(AMap.GeometryUtil.distance([this.mar1, this.mar2], [this.mar3, this.mar4]));
            //点标记
            let m1 = new AMap.Marker({
                map: map,
                position: new AMap.LngLat(this.mar1, this.mar2)
            });
            //第二个位置
            let m2 = new AMap.Marker({
                map: map,
                position: new AMap.LngLat(this.mar3, this.mar4)
            });
            map.setFitView();

            //连线实例
            let line = new AMap.Polyline({
                map: map,
                path: [new AMap.LngLat(this.mar1, this.mar2), new AMap.LngLat(this.mar3, this.mar4)],
                strokeColor: '#80d8ff',
                isOutline: true,
                outlineColor: 'white'
            });
            //文字实例
            let text = new AMap.Text({
                text: this.dis + '米',
                style: {
                    'background-color': '#29b6f6',
                    'border-color': '#e1f5fe',
                    'font-size': '12px'
                }
            });
            text.setMap(map);
            console.log(map);
        });
    }

    public destroy(): void {
        // Add code to cleanup control if necessary
    }
    public getOutputs(): IOutputs {
        console.log(this.dis + "返回距离值");
        return {
            DistanceValue: this.dis.toString()
        };
    }
}
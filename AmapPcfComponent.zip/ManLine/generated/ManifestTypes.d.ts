/*
*This is auto generated from the ControlManifest.Input.xml file
*/

// Define IInputs and IOutputs Type. They should match with ControlManifest.
export interface IInputs {
    ApiKey: ComponentFramework.PropertyTypes.StringProperty;
    Marker1long: ComponentFramework.PropertyTypes.StringProperty;
    Marker1lat: ComponentFramework.PropertyTypes.StringProperty;
    Marker2long: ComponentFramework.PropertyTypes.StringProperty;
    Marker2lat: ComponentFramework.PropertyTypes.StringProperty;
    DistanceValue: ComponentFramework.PropertyTypes.StringProperty;
}
export interface IOutputs {
    ApiKey?: string;
    Marker1long?: string;
    Marker1lat?: string;
    Marker2long?: string;
    Marker2lat?: string;
    DistanceValue?: string;
}
